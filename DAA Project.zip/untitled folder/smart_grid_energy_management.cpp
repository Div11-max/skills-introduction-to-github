
#include <iostream>
#include <vector>
#include <queue>
#include <unordered_map>
#include <list>
#include <algorithm>
#include <climits>
#include <ctime>
#include <cstdlib>
#include <stack>
#include <set>
#include <deque>
#include <map>
#include <sstream>
#include <numeric>
#include <limits>

using namespace std;

struct Edge {
    int src, dest, weight;
};

class Graph {
public:
    int V;
    vector<vector<int>> adjMatrix;
    vector<vector<pair<int, int>>> adjList;
    vector<Edge> edges;

    Graph(int vertices) {
        V = vertices;
        adjList.resize(V);
        adjMatrix.resize(V, vector<int>(V, INT_MAX));
        for (int i = 0; i < V; i++) {
            adjMatrix[i][i] = 0;
        }
    }

    void addOrEditEdge(int u, int v, int weight) {
        if (u >= V || v >= V || u < 0 || v < 0) {
            cout << "Error: Invalid edge (" << u << " -> " << v << "). Node index out of range.\n";
            return;
        }
        adjList[u].push_back({v, weight});
        adjList[v].push_back({u, weight});
        adjMatrix[u][v] = weight;
        adjMatrix[v][u] = weight;
        edges.push_back({u, v, weight});
    }

    vector<int> dijkstra(int src) {
        vector<int> dist(V, INT_MAX);
        priority_queue<pair<int, int>, vector<pair<int, int>>, greater<>> pq;
        dist[src] = 0;
        pq.push({0, src});

        while (!pq.empty()) {
            int u = pq.top().second;
            pq.pop();
            for (auto &[v, weight] : adjList[u]) {
                if (dist[u] + weight < dist[v]) {
                    dist[v] = dist[u] + weight;
                    pq.push({dist[v], v});
                }
            }
        }
        return dist;
    }

    void floydWarshall() {
        for (int k = 0; k < V; k++) {
            for (int i = 0; i < V; i++) {
                for (int j = 0; j < V; j++) {
                    if (adjMatrix[i][k] != INT_MAX && adjMatrix[k][j] != INT_MAX)
                        adjMatrix[i][j] = min(adjMatrix[i][j], adjMatrix[i][k] + adjMatrix[k][j]);
                }
            }
        }
    }

    struct DisjointSet {
        vector<int> parent, rank;
        DisjointSet(int n) {
            parent.resize(n);
            rank.resize(n, 0);
            for (int i = 0; i < n; i++)
                parent[i] = i;
        }
        int find(int u) {
            if (u != parent[u])
                parent[u] = find(parent[u]);
            return parent[u];
        }
        void unite(int u, int v) {
            int rootU = find(u), rootV = find(v);
            if (rootU != rootV) {
                if (rank[rootU] > rank[rootV])
                    parent[rootV] = rootU;
                else if (rank[rootU] < rank[rootV])
                    parent[rootU] = rootV;
                else {
                    parent[rootV] = rootU;
                    rank[rootU]++;
                }
            }
        }
    };

    void kruskalMST() {
        sort(edges.begin(), edges.end(), [](Edge a, Edge b) {
            return a.weight < b.weight;
        });
        DisjointSet ds(V);
        vector<Edge> mstEdges;
        int mstWeight = 0;
        for (Edge &edge : edges) {
            if (ds.find(edge.src) != ds.find(edge.dest)) {
                mstEdges.push_back(edge);
                mstWeight += edge.weight;
                ds.unite(edge.src, edge.dest);
            }
        }
        cout << "\nMinimum Spanning Tree (MST) Edges:\n";
        for (Edge &edge : mstEdges)
            cout << edge.src << " - " << edge.dest << " (Weight: " << edge.weight << ")\n";
        cout << "Total MST Weight: " << mstWeight << endl;
    }
};

unordered_map<int, int> energyConsumption;
unordered_map<int, string> nodeNames;
list<string> historyLog;
stack<pair<int, int>> energyHistoryStack;
set<int> overloadedNodes;
deque<string> maintenanceQueue;
multiset<int> energyStats;

enum UserRole { ADMIN, VIEWER, MAINTENANCE, UNKNOWN };
map<string, pair<string, UserRole>> userDB = {
    {"admin", {"admin123", ADMIN}},
    {"viewer", {"view123", VIEWER}},
    {"maint", {"maint123", MAINTENANCE}}
};
UserRole currentRole = UNKNOWN;

bool isAuthorized(UserRole requiredRole) {
    return currentRole == requiredRole;
}

bool loginSystem() {
    const int maxAttempts = 3;
    int attempt = 0;
    string username, password;
    while (attempt < maxAttempts) {
        cout << "=== Login ===\nUsername: ";
        cin >> username;
        cout << "Password: ";
        cin >> password;
        if (userDB.count(username) && userDB[username].first == password) {
            currentRole = userDB[username].second;
            cout << "Login successful! Role: ";
            if (currentRole == ADMIN) cout << "Admin";
            else if (currentRole == VIEWER) cout << "Viewer";
            else if (currentRole == MAINTENANCE) cout << "Maintenance";
            cout << "\n";
            return true;
        }
        cout << "Login failed. Try again.\n";
        attempt++;
    }
    return false;
}

string currentTimestamp() {
    time_t now = time(0);
    char buf[80];
    strftime(buf, sizeof(buf), "%Y-%m-%d %X", localtime(&now));
    return string(buf);
}

void logEvent(const string &event) {
    historyLog.push_back(currentTimestamp() + " - " + event);
}

void displayDashboard() {
    if (energyStats.empty()) {
        cout << "No data available.\n";
        return;
    }
    int minEnergy = *energyStats.begin();
    int maxEnergy = *energyStats.rbegin();
    double avg = accumulate(energyStats.begin(), energyStats.end(), 0.0) / energyStats.size();

    cout << "\n=== Smart Grid Analytics Dashboard ===\n";
    cout << "Minimum Energy: " << minEnergy << " units\n";
    cout << "Maximum Energy: " << maxEnergy << " units\n";
    cout << "Average Energy: " << avg << " units\n";
}

void displayMenu() {
    cout << "\n=== Smart Grid Menu ===\n";
    cout << "1. Dijkstra's Shortest Paths\n";
    cout << "2. Floyd-Warshall All-Pairs Shortest Path\n";
    cout << "3. Minimum Spanning Tree (Kruskal)\n";
    cout << "4. Add/Edit Edges (Admin Only)\n";
    cout << "5. Display Energy Data\n";
    cout << "6. Update Energy Data\n";
    cout << "7. Show Historical Logs\n";
    cout << "8. Show Maintenance Events\n";
    cout << "9. Show Overloaded Nodes\n";
    cout << "10. Show Smart Grid Analytics Dashboard\n";
    cout << "11. Logout\n";
    cout << "12. Exit\n";
    cout << "Choice: ";
}

void runSystem() {
    int choice, V = 0;
    cout << "Enter number of nodes in the grid (positive integer): ";
    while (!(cin >> V) || V <= 0) {
        cout << "Invalid input. Please enter a positive integer: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }

    Graph powerGrid(V);
    cin.ignore();
    cout << "Enter node names:\n";
    for (int i = 0; i < V; ++i) {
        cout << "Name for Node " << i << ": ";
        getline(cin, nodeNames[i]);
        energyConsumption[i] = 50;
        energyStats.insert(50);
    }

    int numEdges;
    cout << "Enter the number of edges you want to add: ";
    while (!(cin >> numEdges) || numEdges <= 0) {
        cout << "Invalid input. Please enter a positive integer: ";
        cin.clear();
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
    }
    cout << "Enter each edge in format: source destination weight\n";
    for (int i = 0; i < numEdges; ++i) {
        int u, v, w;
        cout << "Edge " << i + 1 << ": ";
        while (!(cin >> u >> v >> w)) {
            cout << "Invalid input. Please enter three integers: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        powerGrid.addOrEditEdge(u, v, w);
    }

    logEvent("Initial energy data recorded.");

    do {
        displayMenu();
        while (!(cin >> choice)) {
            cout << "Invalid input. Please enter a number: ";
            cin.clear();
            cin.ignore(numeric_limits<streamsize>::max(), '\n');
        }
        switch (choice) {
            case 1: {
                vector<int> distances = powerGrid.dijkstra(0);
                cout << "\nShortest paths from Node 0:-\n";
                for (int i = 0; i < V; ++i)
                    cout << "Distance to " << nodeNames[i] << ": " << distances[i] << endl;
                break;
            }
            case 2: {
                powerGrid.floydWarshall();
                cout << "\nFloyd-Warshall All-Pairs Shortest Path Matrix:\n";
                for (int i = 0; i < V; i++) {
                    for (int j = 0; j < V; j++)
                        cout << (powerGrid.adjMatrix[i][j] == INT_MAX ? "INF" : to_string(powerGrid.adjMatrix[i][j])) << "\t";
                    cout << endl;
                }
                break;
            }
            case 3:
                powerGrid.kruskalMST();
                break;
            case 4: {
                if (!isAuthorized(ADMIN)) {
                    cout << "Access denied: Only Admin can add edges.\n";
                    break;
                }
                int e;
                cout << "How many edges do you want to add/edit? ";
                while (!(cin >> e) || e <= 0) {
                    cout << "Invalid input. Please enter a positive integer: ";
                    cin.clear();
                    cin.ignore(numeric_limits<streamsize>::max(), '\n');
                }
                for (int i = 0; i < e; ++i) {
                    int u, v, w;
                    cout << "Edge " << i + 1 << ": ";
                    cin >> u >> v >> w;
                    powerGrid.addOrEditEdge(u, v, w);
                }
                break;
            }
            case 5:
                cout << "\nReal-time Energy Data:\n";
                for (auto &[id, val] : energyConsumption)
                    cout << nodeNames[id] << " (Node " << id << "): " << val << " units\n";
                break;
            case 6: {
                int node, energy;
                cout << "Enter node id and new energy value: ";
                cin >> node >> energy;
                if (energyConsumption.find(node) != energyConsumption.end()) {
                    energyHistoryStack.push({node, energyConsumption[node]});
                    auto it = energyStats.find(energyConsumption[node]);
                    if (it != energyStats.end()) energyStats.erase(it);
                    energyStats.insert(energy);
                    energyConsumption[node] = energy;
                    logEvent("Energy updated for Node " + nodeNames[node] + " to " + to_string(energy));
                    cout << "Energy updated.\n";
                } else {
                    cout << "Invalid node id.\n";
                }
                break;
            }
            case 7:
                cout << "\nHistorical Logs:\n";
                for (const auto &log : historyLog)
                    cout << log << endl;
                break;
            case 8:
                cout << "\nMaintenance Events:\n";
                for (const auto &msg : maintenanceQueue)
                    cout << msg << endl;
                maintenanceQueue.clear();
                break;
            case 9:
                cout << "\nOverloaded Nodes:\n";
                if (overloadedNodes.empty())
                    cout << "No nodes are overloaded.\n";
                else {
                    for (int id : overloadedNodes)
                        cout << nodeNames[id] << " (Node " << id << ") is overloaded.\n";
                }
                break;
            case 10:
                displayDashboard();
                break;
            case 11:
                cout << "Logging out...\n";
                currentRole = UNKNOWN;
                return;
            case 12:
                cout << "Exiting system.\n";
                exit(0);
            default:
                cout << "Invalid option. Try again.\n";
        }
    } while (true);
}

int main() {
    while (!loginSystem()) {
        cout << "Maximum login attempts reached. Exiting.\n";
        return 1;
    }

    while (true) {
        runSystem();
        char again;
        cout << "Do you want to log in again? (y/n): ";
        cin >> again;
        if (tolower(again) != 'y') break;
        cin.ignore(numeric_limits<streamsize>::max(), '\n');
        if (!loginSystem()) break;
    }

    cout << "Exiting application. Goodbye!\n";
    return 0;
}
